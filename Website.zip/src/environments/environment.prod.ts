export const environment = {
	production: true,
	firebase: {
		apiKey: "AIzaSyB-H-VHiOp_wiQbpfy8Hs_NohuR-OEhcsw",
		authDomain: "fetsl-fc873.firebaseapp.com",
		databaseURL: "https://fetsl-fc873.firebaseio.com",
		projectId: "fetsl-fc873",
		storageBucket: "fetsl-fc873.appspot.com",
		messagingSenderId: "160471596987"
	}
};