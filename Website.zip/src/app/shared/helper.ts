export class Helper {
	c_code: string = null;
	c_name: string = null;
	constructor(code:string,name:string){
		this.c_code = code;
		this.c_name = name;
	}
}